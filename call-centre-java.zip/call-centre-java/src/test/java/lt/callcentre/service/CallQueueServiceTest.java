package lt.callcentre.service;

import lt.callcentre.model.Call;
import lt.callcentre.model.CallStatus;
import lt.callcentre.repository.InMemoryCallRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CallQueueServiceTest {
    private CallQueueService service;

    @BeforeEach
    void setUp() {
        InMemoryCallRepository repository = new InMemoryCallRepository();
        service = new CallQueueService(repository);
    }

    @Test
    void oldestRegularCallIsSelected() {
        Call oldCall = new Call(1, "client-a", "+37060000001", false, LocalDateTime.now().minusMinutes(10));
        Call newCall = new Call(2, "client-a", "+37060000002", false, LocalDateTime.now().minusMinutes(2));
        service.addCall(oldCall);
        service.addCall(newCall);
        Call selected = service.takeNextCall("client-a");
        assertEquals(1, selected.getId());
        assertEquals(CallStatus.ACTIVE, selected.getStatus());
    }

    @Test
    void vipCallHasPriority() {
        Call oldRegularCall = new Call(1, "client-a", "+37060000001", false, LocalDateTime.now().minusMinutes(20));
        Call newVipCall = new Call(2, "client-a", "+37060000002", true, LocalDateTime.now().minusMinutes(1));
        service.addCall(oldRegularCall);
        service.addCall(newVipCall);
        Call selected = service.takeNextCall("client-a");
        assertEquals(2, selected.getId());
        assertTrue(selected.isVip());
    }

    @Test
    void emptyQueueReturnsError() {
        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> service.takeNextCall("client-a")
        );
        assertEquals("No waiting calls.", exception.getMessage());
    }

    @Test
    void clientCannotReadOrChangeOtherClientData() {
        Call clientACall = new Call(1, "client-a", "+37060000001", false, LocalDateTime.now());
        Call clientBCall = new Call(2, "client-b", "+37061111111", false, LocalDateTime.now());
        service.addCall(clientACall);
        service.addCall(clientBCall);

        List<Call> clientACalls = service.getCalls("client-a");
        assertEquals(1, clientACalls.size());
        assertEquals("client-a", clientACalls.get(0).getClientId());

        assertThrows(
                IllegalArgumentException.class,
                () -> service.setVip("client-a", 2, true)
        );
        assertFalse(clientBCall.isVip());
    }

    @Test
    void cannotTakeSecondCallWhileAnotherIsActive() {
        service.addCall(new Call(1, "client-a", "+37060000001", false, LocalDateTime.now().minusMinutes(5)));
        service.addCall(new Call(2, "client-a", "+37060000002", false, LocalDateTime.now().minusMinutes(2)));
        service.takeNextCall("client-a");

        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> service.takeNextCall("client-a")
        );
        assertEquals("Client already has an active call.", exception.getMessage());
    }
}
