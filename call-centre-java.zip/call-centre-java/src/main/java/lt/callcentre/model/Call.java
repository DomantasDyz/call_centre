package lt.callcentre.model;

import java.time.LocalDateTime;

public class Call {
    private final int id;
    private final String clientId;
    private final String phoneNumber;
    private boolean vip;
    private final LocalDateTime createdAt;
    private CallStatus status;

    public Call(int id, String clientId, String phoneNumber, boolean vip, LocalDateTime createdAt) {
        this.id = id;
        this.clientId = clientId;
        this.phoneNumber = phoneNumber;
        this.vip = vip;
        this.createdAt = createdAt;
        this.status = CallStatus.WAITING;
    }

    public int getId() { return id; }
    public String getClientId() { return clientId; }
    public String getPhoneNumber() { return phoneNumber; }
    public boolean isVip() { return vip; }
    public void setVip(boolean vip) { this.vip = vip; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public CallStatus getStatus() { return status; }
    public void setStatus(CallStatus status) { this.status = status; }

    @Override
    public String toString() {
        String creationDate = createdAt.toString();
        return "ID=" + id
                + ", numeris=" + phoneNumber
                + ", VIP=" + vip
                + ", statusas=" + status
                + ", sukurtas=" + creationDate;
    }
}
