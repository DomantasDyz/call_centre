package lt.callcentre.repository;

import lt.callcentre.model.Call;
import java.util.ArrayList;
import java.util.List;

public class InMemoryCallRepository {
    private final List<Call> calls = new ArrayList<>();

    public void save(Call call) {
        calls.add(call);
    }

    public List<Call> getCallsForClient(String clientId) {
        List<Call> result = new ArrayList<>();
        for (Call call : calls) {
            if (call.getClientId().equals(clientId)) {
                result.add(call);
            }
        }
        return result;
    }

    public Call findByIdForClient(String clientId, int callId) {
        for (Call call : calls) {
            if (call.getClientId().equals(clientId) && call.getId() == callId) {
                return call;
            }
        }
        return null;
    }
}
