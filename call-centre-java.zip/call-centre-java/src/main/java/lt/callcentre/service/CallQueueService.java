package lt.callcentre.service;

import lt.callcentre.model.Call;
import lt.callcentre.model.CallStatus;
import lt.callcentre.repository.InMemoryCallRepository;

import java.util.ArrayList;
import java.util.List;

public class CallQueueService {
    private final InMemoryCallRepository repository;

    public CallQueueService(InMemoryCallRepository repository) {
        this.repository = repository;
    }

    public void addCall(Call call) {
        repository.save(call);
    }

    public List<Call> getCalls(String clientId) {
        return repository.getCallsForClient(clientId);
    }

    public Call takeNextCall(String clientId) {
        List<Call> clientCalls = repository.getCallsForClient(clientId);

        for (Call call : clientCalls) {
            if (call.getStatus() == CallStatus.ACTIVE) {
                throw new IllegalStateException("Šis operatorius jau turi aktyvų skambutį!");
            }
        }

        List<Call> waitingCalls = new ArrayList<>();
        for (Call call : clientCalls) {
            if (call.getStatus() == CallStatus.WAITING) {
                waitingCalls.add(call);
            }
        }

        if (waitingCalls.isEmpty()) {
            throw new IllegalStateException("Nėra nepakeltų skambučių!");
        }

        Call selected = null;
        for (Call call : waitingCalls) {
            if (selected == null) {
                selected = call;
                continue;
            }
            if (call.isVip() && !selected.isVip()) {
                selected = call;
            } else if (call.isVip() == selected.isVip()
                    && call.getCreatedAt().isBefore(selected.getCreatedAt())) {
                selected = call;
            }
        }

        selected.setStatus(CallStatus.ACTIVE);
        return selected;
    }

    public Call endActiveCall(String clientId) {
        List<Call> clientCalls = repository.getCallsForClient(clientId);
        for (Call call : clientCalls) {
            if (call.getStatus() == CallStatus.ACTIVE) {
                call.setStatus(CallStatus.COMPLETED);
                return call;
            }
        }
        throw new IllegalStateException("Šiuo metu nėra jokių aktyvių skambučių!");
    }

    public void setVip(String clientId, int callId, boolean vip) {
        Call call = repository.findByIdForClient(clientId, callId);
        if (call == null) {
            throw new IllegalArgumentException("Skambučio tokiu ID šiam operatoriui priskirta nėra!");
        }
        if ((call.isVip() && vip) || (!call.isVip() && !vip)) {
            System.err.println("This call is already set to " + (vip ? "top priority" : "low priority") + "!");
            return;
        }
        call.setVip(vip);
    }
}
