# Call Centre – II dalies prototipas

Paprastas Java CLI prototipas, skirtas skambučių eilės valdymui.

## Naudotos technologijos

- Java 21
- Maven 3.9+
- JUnit 5

## Pagrindinė logika

Sistema turi du iš anksto paruoštus klientus: `client-a` ir `client-b`.
Kiekvienas skambutis priklauso vienam klientui.

Kito skambučio parinkimo taisyklės:

1. Klientas gali matyti ir keisti tik savo skambučius.
2. VIP skambutis turi prioritetą prieš paprastą skambutį.
3. Jei prioritetas vienodas, pasirenkamas seniausias laukiančioje eilėje esantis skambutis.
4. Jei klientas jau turi aktyvų skambutį, kito skambučio paimti negalima.
5. Jei nėra laukiančių skambučių, grąžinama klaida.

## Paleidimas

Reikia Java 21 ir Maven.

```bash
mvn compile exec:java
```

## Testai

```bash
mvn test
```

## Pavyzdiniai duomenys

Paleidimo metu sukuriami 4 skambučiai:

- `client-a`: vienas paprastas ir vienas VIP;
- `client-b`: vienas paprastas ir vienas VIP.

## CLI meniu

```text
1. Show calls
2. Add test call
3. Take next call
4. End active call
5. Switch client
6. Change VIP status
0. Exit
```

## Demonstravimo žingsniai

1. Paleisti `mvn compile exec:java`.
2. Pasirinkti `1` ir parodyti `client-a` skambučius.
3. Pasirinkti `3` ir parodyti, kad VIP skambutis parenkamas pirmas.
4. Dar kartą pasirinkti `3` ir parodyti klaidą, nes jau yra aktyvus skambutis.
5. Pasirinkti `4` ir užbaigti aktyvų skambutį.
6. Pasirinkti `5` ir persijungti į `client-b`.
7. Pasirinkti `1` ir parodyti, kad matomi tik `client-b` skambučiai.
8. Paleisti `mvn test` ir parodyti testų rezultatą.

## Automatiniai testai

Testuojama:

- seniausio paprasto skambučio parinkimas;
- VIP prioriteto taisyklė;
- tuščios eilės klaida;
- klientų duomenų izoliacija;
- draudimas paimti antrą skambutį, kai vienas jau aktyvus.
